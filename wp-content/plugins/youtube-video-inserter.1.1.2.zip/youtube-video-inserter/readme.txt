=== YouTube Video Inserter ===
Contributors: ueberhammDesign
Donate link: 
Tags: YouTube, Videos, Video Page, YouTube URL, Shortcode, YouTube API
Requires at least: 3.2
Tested up to: 3.5.1
Stable tag: 1.1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin help you to insert YouTube Videos to your WordPress Blog with Infos from YouTube.

== Description ==

This plugin help you to insert YouTube Videos to your WordPress Blog. You just have to insert the URL and the Plugin get all necessary infos about the Video directly from YouTube.

== Installation ==

1. Upload `youtube-video-inserter` to the `/wp-content/plugins/` directory
1. Activate the YouTube Video Insertet through the 'Plugins' menu in WordPress
1. Insert some Video under 'Insert YT Video' and have fun

== Frequently asked questions ==

= Is the plugin responsive? =

It is full responsive. That plugin calculate the height of the video via JavaScript, also if you change the window size.

= Can I change the default description of the video? =

Yes. You can edit the complete video page with the WordPress-Editor

= Can I see the cideo in thier category? =

Yes. You can see the videos on the categorypage.

= A the plugin arrivable in (insert a language) =

Currently it's just arrivable in English and German.

= A video call a 404 error =

Reset the permalinkstructur in your Wordpress settings and the problem is fixed.


== Changelog ==

= 1.1.2 =
* Bugfixe: Shortcode for the single video now work :-)

= 1.1.1 =
* Bugfixes

= 1.1.0 =
* Add widget: Last uploaded videos
* Add widget: Random videos
* Add functionality to creat .po abd .mo files for translation
* Language support for German now over .po and .mo files
* Small overviewpage design update: Buttons are now ever under the infos
* Bug fix: Offset width at the outputpages

= 1.0.2 =
* Bugfix: Show IDs of navigationselements in Last Post Widget.

= 1.0.1 =
* Add language support (Just German)
* Change a little bit the style of the overview page.