<?php
/**
Plugin Name: TubePress
Plugin URI: http://tubepress.org
Description: Displays gorgeous YouTube and Vimeo galleries in your posts, pages, and/or sidebar. Upgrade to <a href="http://tubepress.org/pro/">TubePress Pro</a> for more features!
Author: Eric D. Hough
Version: 3.0.1
Author URI: http://ehough.com

Copyright 2006 - 2013 TubePress LLC (http://tubepress.org)

This file is part of TubePress (http://tubepress.org)

This Source Code Form is subject to the terms of the Mozilla Public
License, v. 2.0. If a copy of the MPL was not distributed with this
file, You can obtain one at http://mozilla.org/MPL/2.0/.
*/

include 'src/main/php/scripts/boot.php';
